﻿# instalar-api.ps1 — Corre no servidor como Administrador
$ErrorActionPreference = "Stop"
$apiDir = "C:\WebServicosAPI"
New-Item -ItemType Directory -Force -Path $apiDir | Out-Null
Copy-Item "C:\WebServicosAPI_mini\*" $apiDir -Force

$svc = Get-Service "WebServicosAPI" -ErrorAction SilentlyContinue
if ($svc) { sc.exe stop WebServicosAPI 2>&1 | Out-Null; Start-Sleep 2; sc.exe delete WebServicosAPI | Out-Null; Start-Sleep 1 }

# Usar o runtime da app principal para arrancar a API
$exePath = "C:\WebServicos\dotnet-api-runner.bat"
New-Service -Name "WebServicosAPI" `
            -DisplayName "WebServicos - API REST" `
            -BinaryPathName ""$apiDir\WebServicos.API.exe"" `
            -StartupType Automatic

$regPath = "HKLM:\SYSTEM\CurrentControlSet\Services\WebServicosAPI"
New-ItemProperty -Path $regPath -Name "Environment" -PropertyType MultiString `
    -Value @("ASPNETCORE_ENVIRONMENT=Production","ASPNETCORE_URLS=http://localhost:5001") `
    -Force | Out-Null

Start-Service "WebServicosAPI"
Write-Host "API a correr em http://localhost:5001" -ForegroundColor Green
